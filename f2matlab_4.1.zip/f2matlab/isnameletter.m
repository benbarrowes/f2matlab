function out=isnameletter(str)
out=((isletter(str))|(str=='_'));
