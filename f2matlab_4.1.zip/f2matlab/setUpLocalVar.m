localVar=cell(1,19);
localVar{1,1}=dumvar;   %name: name of var
localVar{1,2}=1;        %nDim: length of charater data type
localVar{1,3}='real';   %type: type of var
localVar{1,4}=[];        %common: var is 1=>common or not=>0 (or are from a module)
localVar{1,5}=cell(0);  %extents: extents of var in each dimension, 
                        %localVar{1,5}{1} is the first subscript,
                        %localVar{1,5}{2} is the second subscript, etc.
localVar{1,6}=[];        %data: data=>1 or not=>0
localVar{1,7}=[];        %save: saved=>1 or not=>0
localVar{1,8}=[];        %protect: can't be taken out of localVar=>1 (protected) or can=>0
localVar{1,9}=[];        %param: declared as parameter=>1 or not=>0
localVar{1,10}=[];       %intent: in=>1, out=>2, or inout=>3
localVar{1,11}=[];       %alloc: allocatable=>1 or not=>0 (also pointers ase 1)
localVar{1,12}=[];       %external: external=>1 or not=>0 or empty on all the 0's
localVar{1,13}=[];       %input: (input var)=>(# which input) or (not an input var)=>0
localVar{1,14}=[];       %optional: optional input => 1, or not
localVar{1,15}=[];       %result(varname) or not
localVar{1,16}=[];       %handle: function handle => 1, or not => 0
localVar{1,17}=[];       %default: mostly for types with default values
localVar{1,18}=[];       %private: if this was declared private or not
localVar{1,19}=[];       %declaredin: which unit this was declared in