classdef pntr < handle
 properties
  data
 end
 methods
  function display(obj)
   display(obj.data)
  end
  function disp(obj)
   disp(obj.data)
  end
 end
end
