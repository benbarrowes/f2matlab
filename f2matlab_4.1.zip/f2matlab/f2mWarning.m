function  f2mWarning(str,funstr,nLine,loc)

disp(str)
disp(funstr{nLine})
disp([repmat(' ',1,loc-1),'^'])