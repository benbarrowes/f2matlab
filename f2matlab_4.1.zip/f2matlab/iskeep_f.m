function out=iskeep_f(str)
if ~isempty(str)
 out=((isletter(str))|(str=='_')|(str=='.')|((str>47)&(str<58)));
else
 out=[];
end
