function out=isnumber(str)
%out=(((str>47)&(str<58))|(str==46));
out=((str>47)&(str<58));
