function ztest
persistent n 
if isempty(n),n=5;
;
end;
global bcom_1; 
global bcom_2; 
global bl1_1; 
global bl1_2; 
global bl2_1; 
global bl2_2; 
bcom_1=1;
bcom_2=2;
bl1_1=3;
bl1_2=4;
bl2_1=5;
bl2_2(:)=6;
fprintf(1,'%s ','bcom_1=');
fprintf(1,'%0.15g \n',bcom_1);
fprintf(1,'%s ','bcom_2=');
fprintf(1,'%0.15g \n',bcom_2);
fprintf(1,'%s ','bl1_1=');
fprintf(1,'%0.15g \n',bl1_1);
fprintf(1,'%s ','bl1_2=');
fprintf(1,'%0.15g \n',bl1_2);
fprintf(1,'%s ','bl2_1=');
fprintf(1,'%0.15g \n',bl2_1);
fprintf(1,'%s ','bl2_2=');
fprintf(1,'%0.15g \n',bl2_2);
sub1;
fprintf(1,'%s ','bcom_1=');
fprintf(1,'%0.15g \n',bcom_1);
fprintf(1,'%s ','bcom_2=');
fprintf(1,'%0.15g \n',bcom_2);
fprintf(1,'%s ','bl1_1=');
fprintf(1,'%0.15g \n',bl1_1);
fprintf(1,'%s ','bl1_2=');
fprintf(1,'%0.15g \n',bl1_2);
fprintf(1,'%s ','bl2_1=');
fprintf(1,'%0.15g \n',bl2_1);
fprintf(1,'%s ','bl2_2=');
fprintf(1,'%0.15g \n',bl2_2);
end %program ztest
function sub1
global bcom_1; 
global bcom_2; 
global bl1_1; 
global bl1_2; 
bcom_1=10;
bcom_2=20;
bl1_1=30;
bl1_2=40;
b5=50;
b6=60;
return;
end %subroutine sub1

