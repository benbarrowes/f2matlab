function ans = ztest1(vect1, vect2)
for i=1:length(vect1)
 ans(i) = vect1(i) + vect2(i);
end