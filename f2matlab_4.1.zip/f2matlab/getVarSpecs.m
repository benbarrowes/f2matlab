function out=getVarSpecs(varName,localVar,typeDefs)

